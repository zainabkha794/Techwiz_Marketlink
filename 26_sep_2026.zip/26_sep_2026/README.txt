### Day 3 – Branching and Team Collaboration

- Planned the project division into three development branches.
- Identified the Controllers, Models, Views, and other project components.
- Divided the project features among the development branches.
- Created separate branches for different features/modules.
- Added and committed feature-specific changes.
- Pushed the branches to GitHub.
- Prepared the project for collaborative development and future merging.
