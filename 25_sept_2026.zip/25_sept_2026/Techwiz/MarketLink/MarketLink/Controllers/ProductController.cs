﻿using Microsoft.AspNetCore.Mvc;
using MarketLink.Models;
using System.Linq;

namespace MarketLink.Controllers
{
    public class ProductController : Controller
    {
        private readonly MarketLinkContext _context;

        public ProductController(MarketLinkContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            var products = _context.Products
                .Where(p => p.IsAvailable == true)
                .ToList();

            return View(products);
        }

        public IActionResult Details(int id)
        {
            var product = _context.Products
                .FirstOrDefault(p => p.ProductId == id);

            if (product == null)
            {
                return NotFound();
            }

            return View(product);
        }

        [HttpPost]
        public IActionResult AddToCart(int id)
        {
            var product = _context.Products
                .FirstOrDefault(p => p.ProductId == id);

            if (product == null)
            {
                return NotFound();
            }

            TempData["CartMessage"] = $"{product.Name} added to cart successfully!";

            return RedirectToAction("Details", new { id = id });
        }
    }
}