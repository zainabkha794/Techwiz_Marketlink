﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MarketLink.Models;
using System.Linq;

namespace MarketLink.Controllers
{
    public class FarmerController : Controller
    {
        private readonly MarketLinkContext _context;

        public FarmerController(MarketLinkContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            int? farmerId = HttpContext.Session.GetInt32("UserId");

            if (farmerId == null)
            {
                return RedirectToAction("Login", "Auth");
            }

            var products = _context.Products
                .Where(p => p.FarmerId == farmerId)
                .ToList();

            return View(products);
        }
    }
}