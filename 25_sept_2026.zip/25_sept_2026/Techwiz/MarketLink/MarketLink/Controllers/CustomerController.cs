﻿using Microsoft.AspNetCore.Mvc;
using MarketLink.Models;

namespace MarketLink.Controllers
{
    public class CustomerController : Controller
    {
        private readonly MarketLinkContext _context;

        public CustomerController(MarketLinkContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            return View();
        }
    }
}
