﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using MarketLink.Models;
using System.Linq;

namespace MarketLink.Controllers
{
    public class AuthController : Controller
    {
        private readonly MarketLinkContext _context;

        public AuthController(MarketLinkContext context)
        {
            _context = context;
        }

        // =========================
        // LOGIN - GET
        // =========================
        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        // =========================
        // LOGIN - POST
        // =========================
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Login(string email, string password)
        {
            var user = _context.Users
                .FirstOrDefault(u =>
                    u.Email == email &&
                    u.PasswordHash == password);

            if (user == null)
            {
                ViewBag.Error = "Invalid email or password.";
                return View();
            }

            // Save user information in session
            HttpContext.Session.SetInt32("UserId", user.UserId);
            HttpContext.Session.SetString("UserRole", user.Role ?? "");
            HttpContext.Session.SetString("UserName", user.FullName);
            HttpContext.Session.SetString("UserEmail", user.Email);

            // Redirect according to role
            if (user.Role == "Admin")
            {
                return RedirectToAction("Index", "Admin");
            }

            if (user.Role == "Farmer")
            {
                return RedirectToAction("Index", "Farmer");
            }

            return RedirectToAction("Index", "Customer");
        }

        // =========================
        // REGISTER - GET
        // =========================
        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }

        // =========================
        // REGISTER - POST
        // =========================
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Register(User user)
        {
            if (!ModelState.IsValid)
            {
                return View(user);
            }

            // Check if email already exists
            var existingUser = _context.Users
                .FirstOrDefault(u => u.Email == user.Email);

            if (existingUser != null)
            {
                ModelState.AddModelError(
                    "Email",
                    "Email already exists."
                );

                return View(user);
            }

            // Default role
            if (string.IsNullOrEmpty(user.Role))
            {
                user.Role = "Customer";
            }

            _context.Users.Add(user);
            _context.SaveChanges();

            TempData["Success"] =
                "Registration successful. Please login.";

            return RedirectToAction("Login");
        }

        // =========================
        // LOGOUT
        // =========================
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();

            return RedirectToAction("Login");
        }
    }
}