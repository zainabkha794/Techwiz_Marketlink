﻿using System;
using System.Collections.Generic;

namespace MarketLink.Models;

public partial class ViewTopSellingProduct
{
    public int ProductId { get; set; }

    public string ProductName { get; set; } = null!;

    public string FarmerName { get; set; } = null!;

    public int? TotalUnitsSold { get; set; }

    public decimal? TotalRevenue { get; set; }
}
