﻿using System;
using System.Collections.Generic;

namespace MarketLink.Models;

public partial class Order
{
    public int OrderId { get; set; }

    public int? CustomerId { get; set; }

    public int? FarmerId { get; set; }

    public DateOnly PickupDate { get; set; }

    public string? TimeSlot { get; set; }

    public string? Status { get; set; }

    public virtual User? Customer { get; set; }

    public virtual User? Farmer { get; set; }

    public virtual ICollection<OrderItem> OrderItems { get; set; } = new List<OrderItem>();
}
