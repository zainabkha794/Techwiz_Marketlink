﻿using System;
using System.Collections.Generic;

namespace MarketLink.Models;

public partial class Product
{
    public int ProductId { get; set; }

    public int? FarmerId { get; set; }

    public string Name { get; set; } = null!;

    public string? Category { get; set; }

    public decimal Price { get; set; }

    public int StockQuantity { get; set; }

    public bool? IsAvailable { get; set; }

    public string? ImageUrl { get; set; }

    public virtual User? Farmer { get; set; }

    public virtual ICollection<OrderItem> OrderItems { get; set; } = new List<OrderItem>();

    public virtual ICollection<Review> Reviews { get; set; } = new List<Review>();
}
