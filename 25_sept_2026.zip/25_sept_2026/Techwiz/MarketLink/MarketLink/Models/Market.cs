﻿using System;
using System.Collections.Generic;

namespace MarketLink.Models;

public partial class Market
{
    public int MarketId { get; set; }

    public string MarketName { get; set; } = null!;

    public string Address { get; set; } = null!;

    public decimal? Latitude { get; set; }

    public decimal? Longitude { get; set; }

    public string? OperatingDays { get; set; }

    public string? Timings { get; set; }
}
