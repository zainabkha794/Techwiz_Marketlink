### Day 2 – Git and GitHub Setup

- Initialized Git version control for the project.
- Created a GitHub repository named `MarketLink`.
- Connected the local project with the GitHub repository.
- Added the project files to Git.
- Created the initial project commit.
- Pushed the project files to GitHub.
- Created the first development branch named `branch1`.
